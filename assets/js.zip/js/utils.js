
               // ============ HELPERS ============
        function toBangla(n) {
            const d = ['০','১','২','৩','৪','৫','৬','৭','৮','৯'];
            return String(n).replace(/\d/g, c => d[+c]);
        }

           // ============ TOAST ============
        function showToast(msg) {
            const t = document.getElementById('toast');
            t.textContent = msg; t.classList.add('show');
            setTimeout(() => t.classList.remove('show'), 3500);
        }